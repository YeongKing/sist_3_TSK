package TeamHomeWork;

public class workEvent {
	private String userId; //로그인성공한 당시 접속된 userId
	
	public workEvent() {
		

		
		
		
		
	}

	
	
	
}
